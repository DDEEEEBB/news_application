class AppRoutes {
  AppRoutes._();

  static const String splash ="/";
  static const String homeScreen ="home";
  static const String NewsScreen ="news";

}


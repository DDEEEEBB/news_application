import 'dart:ui';

class AppColors {
  AppColors._();

  static const Color black = Color(0xff000000);
  static const Color white = Color(0xffFFFFFF);
}